# python

"""PDX-License-Identifier: Apache-2.0
Copyright Contributors to the ODPi Egeria project.

This folder provides style settings for the different components of the my_egeria module.


"""