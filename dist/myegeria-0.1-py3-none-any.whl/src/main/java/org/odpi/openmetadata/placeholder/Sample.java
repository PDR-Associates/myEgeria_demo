/* SPDX-License-Identifier: Apache-2.0 */
/* Copyright Contributors to the ODPi Egeria project. */

package org.odpi.openmetadata.placeholder;

/**
 * TODO: Sample has no implementation - you need to replace this code
 */
public class Sample {
}
