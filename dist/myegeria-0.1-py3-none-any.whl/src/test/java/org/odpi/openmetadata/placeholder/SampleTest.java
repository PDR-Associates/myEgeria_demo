/* SPDX-License-Identifier: Apache-2.0 */
/* Copyright Contributors to the ODPi Egeria project. */

// TODO: Remove placeholder test code & replace with real code
package org.odpi.openmetadata.placeholder;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;


/**
 * KafkaMonitorIntegrationConnector catalogues active topics in a Strimzi broker.
 */
public class SampleTest {

    @Test
    public void testSample() {
        assertTrue(true);
    }
}
